a = 7
if a < 12:
    print("Goodmorning!")
elif a < 17:
    print("Good Afternoon!")
elif a <21:
    print("Good Evening!")
else:
    print("Good night!")