import numpy as np
print(np.zeros(10))
print(np.zeros((2,5)))
print(np.ones(10))
print(np.random.rand(10))
print(np.arange(0,1,0.2))
print(np.linspace(0,10,7))