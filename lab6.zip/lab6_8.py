import numpy as np


a = np.array([3,7,2,1,9])
print(a[2])
a[2] = 4
print(a[2])
b = np.array(([0,1,3],[2,4,5]))
print(b[1,2])
print(b[1])