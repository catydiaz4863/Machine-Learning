import numpy as np

a = np.array([0,1,2,3])
b = 3

print(a*b)